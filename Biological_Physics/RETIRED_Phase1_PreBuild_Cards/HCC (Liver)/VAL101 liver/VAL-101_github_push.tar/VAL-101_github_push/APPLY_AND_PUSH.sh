#!/bin/bash
# VAL-101 + VAL-102 voided GitHub push — apply on Heath's local clone of IAM-Validation
# PATH A (cleanest): git am the .patch file (preserves authorship + commit message)
# PATH B (fallback): copy raw_files/* + single new commit
#
# Usage: from inside your local IAM-Validation clone, run:
#   bash /path/to/APPLY_AND_PUSH.sh

set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PATCH_FILE=$(ls "$SCRIPT_DIR"/*.patch 2>/dev/null | head -1)

echo "=== VAL-101 + VAL-102 voided push application ==="
echo "Repo working dir: $(pwd)"
git status --short | head -5

if [ -n "$PATCH_FILE" ]; then
  echo
  echo "Applying patch: $PATCH_FILE"
  if ! git am "$PATCH_FILE"; then
    echo "git am failed — aborting and falling back to PATH B (manual copy)..."
    git am --abort 2>/dev/null
    cp -r "$SCRIPT_DIR/raw_files/Biological_Physics/validation_runs/VAL-101" Biological_Physics/validation_runs/
    cp -r "$SCRIPT_DIR/raw_files/Biological_Physics/validation_runs/VAL-102" Biological_Physics/validation_runs/
    cp "$SCRIPT_DIR/raw_files/Biological_Physics/README.md" Biological_Physics/README.md
    git add Biological_Physics/validation_runs/VAL-101/ \
            Biological_Physics/validation_runs/VAL-102/ \
            Biological_Physics/README.md
    git commit -m "VAL-101 hcc-epic 25-tile etiology stratification sealed at O5; VAL-102 voided before execution; CCL-041 logged" \
               -m "VAL-101 (TCGA-LIHC paired n=46): pre-locked CHK-3.1 raw-EPIC threshold tripped (extreme 26.6% / middle 9.1%) — outcome O5_DATA_INTEGRITY_FLAG. Biological readouts (Hepatocytes pooled d=-1.521; Marcus-analog No_documented_risk n=10 d=-1.141; etc.) descriptive supplementary only, do NOT propagate. hcc-epic card stays at v0.2. Prereg SHA fa366bf00316597b..." \
               -m "VAL-102 voided 2026-04-28T20:35Z within 4 minutes of seal (SHA 2b77ad9d3b69554a...) — identified as post-hoc threshold accommodation with a SHA stamp; threshold derived from VAL-101's tripped data, applied to same cohort = circular reasoning. Audit trail preserved per cookbook discipline (cookbook does not delete sealed records)." \
               -m "CCL-041 LL-CHK-3.1-PLATFORM-CALIBRATION formalized: CHK-3.1 thresholds need platform-specific tuning. Raw EPIC vs TCGA HM450 sesame Level 3 read different bimodality due to TCGA dye bias correction. Threshold for any new platform MUST be set by calibration VAL on structurally-separated cohort, NOT by retroactive accommodation. Distinct from CCL-040 (which covers processed-output deferral). TCGA HM450 platform threshold value itself remains TBD pending future calibration VAL."
  fi
fi

echo
echo "Pushing to origin/main..."
git push origin main
echo
echo "=== Done ==="

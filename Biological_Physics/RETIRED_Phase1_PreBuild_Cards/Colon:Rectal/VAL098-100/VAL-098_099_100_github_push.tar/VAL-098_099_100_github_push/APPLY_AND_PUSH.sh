#!/bin/bash
# VAL-098 + VAL-099 + VAL-100 GitHub push — apply on Heath's local clone of IAM-Validation
# Two paths:
#   PATH A (cleanest): git am the .patch file — preserves authorship and full commit message
#   PATH B (fallback): copy raw_files/* into your repo, single new commit
#
# Usage: from inside your local IAM-Validation clone, run:
#   bash /path/to/APPLY_AND_PUSH.sh

set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PATCH_FILE=$(ls "$SCRIPT_DIR"/*.patch 2>/dev/null | head -1)

echo "=== VAL-098 + VAL-099 + VAL-100 push application ==="
echo "Repo working dir: $(pwd)"
git status --short | head -5

# PATH A — git am the patch
if [ -n "$PATCH_FILE" ]; then
  echo
  echo "Applying patch: $PATCH_FILE"
  if ! git am "$PATCH_FILE"; then
    echo "git am failed — aborting and falling back to PATH B (manual copy)..."
    git am --abort 2>/dev/null
    cp -r "$SCRIPT_DIR/raw_files/Biological_Physics/validation_runs/VAL-098" Biological_Physics/validation_runs/
    cp -r "$SCRIPT_DIR/raw_files/Biological_Physics/validation_runs/VAL-099" Biological_Physics/validation_runs/
    cp -r "$SCRIPT_DIR/raw_files/Biological_Physics/validation_runs/VAL-100" Biological_Physics/validation_runs/
    cp "$SCRIPT_DIR/raw_files/Biological_Physics/README.md" Biological_Physics/README.md
    git add Biological_Physics/validation_runs/VAL-098/ \
            Biological_Physics/validation_runs/VAL-099/ \
            Biological_Physics/validation_runs/VAL-100/ \
            Biological_Physics/README.md
    git commit -m "VAL-098 + VAL-099 + VAL-100: crc-epic v2.4 early-onset rectal subsection three-VAL chain" \
               -m "VAL-098 TCGA-READ paired tissue arm rectal anchor (n=7, d=+0.612 [+0.227, +1.882], O1_CYCLING_CLASS_RECTAL_CONFIRMED, prereg SHA 57d830d6c7ba6448...)" \
               -m "VAL-099 TCGA-COAD age-stratified re-analysis (n=26, pooled d=+0.7241 reproduces VAL-062 byte-for-byte; under-50 stratum n=3 mean delta-A=+0.0357 descriptive-only per CHK-2.7; O1_AGE_STRATIFIED_DIRECTION_CONFIRMED, prereg SHA 8e4ee02c59774514...)" \
               -m "VAL-100 GSE282666 under-50 buffy coat polyp Stage 1 immune (n=51 EPIC v2.0, FIRST cookbook VAL on GPL33022; CHK-3.1 beta distribution check FAILED — supplementary file is minfi noob-bg-corrected per Kumar 2024 Methods, not raw beta; observed d=+0.236 NOT interpreted under O5_DATA_INTEGRITY_FLAG per CCL-032; deferred to v0.2+ raw IDAT processing per CCL-040 (third cookbook instance of pattern; precedent VAL-076 + VAL-077); prereg SHA 4017913d31b31e03...)" \
               -m "CCL-039 LL-MARKER-CPG-TILE-FIDELITY confirmed cookbook-wide on three independent paired tumor/adjacent-normal cohort configurations (TCGA-READ tile d=-2.501; TCGA-COAD revisit d=-1.552; TCGA-COAD VAL-099 reproduction d=-1.603)" \
               -m "Bio_Physics/README.md validation table extended with VAL-098 + VAL-099 + VAL-100 rows."
  fi
fi

echo
echo "Pushing to origin/main..."
git push origin main
echo
echo "=== Done ==="
